package BusinessLayer;

public abstract class Shapes implements IMovable, IComputable {
	public EnumTypeColor color;
	private int xCoordinate;
	private int yCoordinate;
	private int identifier;
	private String name;
	
	//Getters and Setters
	public void setIdentifier(int identifier) {
		this.identifier = identifier;
	}
	public int getIdentifier() {
		return identifier;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setXCoordinate(int xCoordinate) {
		this.xCoordinate = xCoordinate;
	}
	public int getXCoordinate() {
		return xCoordinate;
	}
	public void setYCoordinate(int yCoordinate) {
		this.yCoordinate = yCoordinate;
	}
	public int getYCoordinate() {
		return yCoordinate;
	}
	
	//Cons.
	public Shapes(){
		this.identifier = 0;
		this.name = "";
		this.xCoordinate = 0;
		this.yCoordinate = 0;
	}
	public Shapes(int id, String name, int x, int y){
		this.identifier = id;
		this.name = name;
		this.xCoordinate = x;
		this.yCoordinate = y;
	}
	public String toString(){
		return "Identifier: " + this.identifier + "\nName: " + this.name + "\nCoord. in X: " + this.xCoordinate + "\nCoord. in Y: " + this.yCoordinate;
	}

	public abstract String move(int m);
	public abstract double calculArea();
	
}
