package BusinessLayer;
import java.util.Comparator;

public class AreaPredicate implements Comparator<Shapes> {
	public int compare(Shapes s1, Shapes s2)
	{
		if(s1.calculArea() > s2.calculArea())
		{return +1;}
		else if(s1.calculArea() < s2.calculArea())
		{return -1;}
		else 
		{return 0;}
	}
}
