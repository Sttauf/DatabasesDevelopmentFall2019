package BusinessLayer;

public enum EnumTypeColor {
	Dark, Blue;
}
