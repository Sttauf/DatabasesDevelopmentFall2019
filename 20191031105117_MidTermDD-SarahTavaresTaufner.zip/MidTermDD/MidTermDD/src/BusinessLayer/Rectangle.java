package BusinessLayer;

public class Rectangle extends Shapes {
	private int length;
	private int width;
	
	public void setLength(int l) {
		this.length = l;
	}
	public int getLength() {
		return length;
	}
	public void setWidth(int w) {
		this.width = w;
	}
	public int getWidth() {
		return width;
	}	
	
	public Rectangle(){
		super();
		this.length = 0;
		this.width = 0;
	}
	public Rectangle(int id, String name, int x, int y, int l, int w){
		super(id, name, x, y);
		this.length = l;
		this.width = w;
	}
	public String toString(){
		return super.toString() + "\nLength: " + this.length + "\nWidth: " + this.width;
	}
	@Override
	public String move(int m){
		switch(m)
		{
		case 1://RIGHT
			this.setXCoordinate(this.getXCoordinate() + 1);
		break;
		case 2://LEFT
			this.setXCoordinate(this.getXCoordinate() - 1);
		break;
		case 3://UP
			this.setYCoordinate(this.getYCoordinate() + 1);
		break;
		case 4://DOWN
			this.setYCoordinate(this.getYCoordinate() - 1);
		break;
		}
		
		return "Coordinate Updated: " + "\nCoordinate in X: " + this.getXCoordinate() + "\nCoordinate in Y: "+ this.getYCoordinate();
	}
	public double calculArea()
	{
		return (this.length*this.width); 
	}
}
