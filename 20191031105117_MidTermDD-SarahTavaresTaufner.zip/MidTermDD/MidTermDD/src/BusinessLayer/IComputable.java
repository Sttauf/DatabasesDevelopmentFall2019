package BusinessLayer;

public interface IComputable {
	public abstract double calculArea();
}
