package BusinessLayer;

public interface IMovable {
public abstract String move(int m);
}
