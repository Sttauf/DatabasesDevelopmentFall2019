package BusinessLayer;

public class Ellipse extends Shapes {
	private int xRadius;
	private int yRadius;

	public void setXRadius(int xRadius) {
		this.xRadius = xRadius;
	}
	public int getXRadius() {
		return xRadius;
	}
	public void setYRadius(int yRadius) {
		this.yRadius = yRadius;
	}
	public int getYRadius() {
		return yRadius;
	}

	public Ellipse(){
		super();
		this.xRadius = 0;
		this.yRadius = 0;
	}
	public Ellipse(int id, String name, int x, int y, int xR, int yR){
		super(id, name, x, y);
		this.xRadius = xR;
		this.yRadius = yR;
	}
	public String toString(){
		return super.toString() + "\nRadius in X: " + this.xRadius + "\nRadius in Y: " + this.yRadius;
	}
	@Override
	public String move(int m){
		switch(m)
		{
		case 1://RIGHT
			this.setXCoordinate(this.getXCoordinate() + 1);
		break;
		case 2://LEFT
			this.setXCoordinate(this.getXCoordinate() - 1);
		break;
		case 3://UP
			this.setYCoordinate(this.getYCoordinate() + 1);
		break;
		case 4://DOWN
			this.setYCoordinate(this.getYCoordinate() - 1);
		break;
		}
		
		return "Coordinate Updated: " + "\nCoordinate in X: " + this.getXCoordinate() + "\nCoordinate in Y: "+ this.getYCoordinate();
	}
	public double calculArea()
	{
		return (3.14 * this.xRadius * this.yRadius);
	}

}
