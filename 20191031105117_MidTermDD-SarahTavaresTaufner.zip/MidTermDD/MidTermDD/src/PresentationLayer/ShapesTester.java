package PresentationLayer;
import BusinessLayer.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ShapesTester {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		//List of each element
		ArrayList<Shapes> listofShapes = new ArrayList<Shapes>();
		ArrayList<Ellipse> listofEllipses = new ArrayList<Ellipse>();
		ArrayList<Rectangle> listofRectangles = new ArrayList<Rectangle>();
		
		//Variables
		int menuOption = 0;
		int submenuOption = 0;
		int defaultIdentifier = 0;
		boolean found = false;
		
		//MENU:
		do{
		found = false;
		System.out.print("Welcome to the Shape Creator. \nPlease, choose one of the options: \n 1: Add a shape into a collection \n 2: Display all shapes \n 3: Remove an specific shape from the collection \n 4: Search for a specific shape \n 5: Sort the shapes by surface area(in descending order) \n 6: Display each type of geometric shape \n 7: Move a specific shape \n 8: Exit ");
		scan.nextInt(menuOption);
		
		//Switch the option received
		switch(menuOption)
		{
		case 1: //Add a shape
			System.out.print("----ADD A SHAPE----" + "\nWhich shape do you want to add? " + "\n0: Rectangle" + "\n1: Ellipse");
			scan.nextInt(submenuOption);
			
			//Adding a Rectangle
			if(submenuOption == 0){
				Rectangle r1 = new Rectangle();
				r1.setIdentifier(defaultIdentifier++);
				r1.setName("Rectangle"+(defaultIdentifier+1));

				System.out.print("RECTANGLE: " + "\n Write the length: ");
				scan.nextInt(r1.getLength());
				System.out.print("\n Write the Width: ");
				scan.nextInt(r1.getWidth());
				
				listofShapes.add(r1);
			} 
			
			//Adding an Ellipse
			else if(submenuOption == 1){
				Ellipse e1 = new Ellipse();
				e1.setIdentifier(defaultIdentifier++);
				e1.setName("Ellipse"+(defaultIdentifier+1));

				System.out.print("ELLIPSE: " + "\n Write the Radius in X: ");
				scan.nextInt(e1.getXRadius());
				System.out.print("\n Write the Radius in Y: ");
				scan.nextInt(e1.getYRadius());
				
				listofShapes.add(e1);
			}
			
			//Adding to its respective list
			for(Shapes element : listofShapes){
				if(element instanceof Ellipse)
				{
					listofEllipses.add((Ellipse)element);
				} else if(element instanceof Rectangle)
				{
					listofRectangles.add((Rectangle)element);
				}
			}
		break;
		case 2: //Display all the shapes
			System.out.print("----DISPLAY ALL SHAPES----");
			
			try
			{				
				System.out.print("\nList of Shapes: ");
				for (Shapes element : listofShapes)
				{
					System.out.print(element);
				}
			}
			catch (Exception e){System.out.print("There is no shape in your list");}
		break;
		case 3: //Remove a shape
			System.out.print("----REMOVE A SHAPE----");
			
			System.out.print("What is the identifier of the shape that you want to delete? ");
			scan.nextInt(submenuOption);
			do{
			for (Shapes element : listofShapes)
			{
				if(element.getIdentifier() == submenuOption){
					System.out.println("The shape " + element + " was successfully removed.");
					listofShapes.remove(element);
					found = true;
				}else{found = false;}
			}
			}while(found);
		break;
		case 4: //Search a shape
			System.out.print("----SEARCH A SHAPE----");
			
			AreaPredicate areaSort = new AreaPredicate();
			Collections.sort(listofShapes, areaSort);
			
			System.out.print("What is the identifier of the shape that you are looking for? ");
			scan.nextInt(submenuOption);
			do{
			for (Shapes element : listofShapes)
			{
				if(element.getIdentifier() == submenuOption){
					System.out.print(element);
					found = true;
				}else{found = false;}
			}
			}while(found);
			
		break;
		case 5: //Sort shapes by area
			System.out.print("----SORT SHAPES BY AREA----");
			
			AreaPredicate areaSort1 = new AreaPredicate();
			Collections.sort(listofShapes, areaSort1);
			System.out.print("\n Sorted list of Shapes: ");
			for(Shapes element : listofShapes){
				System.out.print(element);
			}
		break;
		case 6: //Display each shape
			System.out.print("----DISPLAY EACH TYPE OF SHAPES----");
			
			try
			{				
				System.out.print("\nList of Ellipses: ");
				for (Ellipse element : listofEllipses)
				{
					System.out.print(element);
				}
				System.out.print("\nList of Rectangles: ");
				for (Rectangle element : listofRectangles)
				{
					System.out.print(element);
				}
			}
			catch (Exception e){System.out.print("There is no shape in your list");}
		break;
		case 7: //Move shape
			System.out.print("----MOVE SHAPE:----");
			System.out.print("What is the identifier of the shape that you are looking for? ");
			scan.nextInt(submenuOption);

			do{
				for (Shapes element : listofShapes)
				{
					if(element.getIdentifier() == submenuOption){
						System.out.print("Do you want to go (1)Right, (2)Left, (3)Up or (4)Down? ");
						scan.nextInt(submenuOption);
						element.move(submenuOption);
						found = true;
					}else{found = false;}
				}
				}while(found);
			
		break;
		}
		}while (menuOption ==8);
		}

}
