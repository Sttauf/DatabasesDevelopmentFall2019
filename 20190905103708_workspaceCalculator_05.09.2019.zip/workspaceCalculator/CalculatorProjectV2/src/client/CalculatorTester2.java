package client;
import java.util.Scanner;

//Version 1.2 - Date: 03.09.2019
public class CalculatorTester2 
{
	public static void main(String[] args) 
	{
		double n1, n2;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("\n\n\t\t Hi... we are building a simple calculator \n");
		System.out.print(" number1 ? : ");
		n1 = scan.nextDouble();
		System.out.print(" number2 ? : ");
		n2 = scan.nextDouble();
		
		System.out.println(n1+ " + " + n2 + " = " + add(n1,n2));
		System.out.println(n1+ " - " + n2 + " = " + sub(n1,n2));
		System.out.println(n1+ " * " + n2 + " = " + mult(n1,n2));
		System.out.println(n1+ " / " + n2 + " = " + div(n1,n2));
		scan.close();
	}
	private static double add(double n1, double n2) 
	{
		return n1 + n2;
	}
	private static double sub(double n1, double n2) 
	{
		return n1 - n2;
	}
	private static double mult(double n1, double n2) 
	{ 
		return n1 * n2; 
	}
	private static double div(double n1, double n2) 
	{
		if(n2 != 0)
		{ 
			return n1 / n2;
		} 
		return 0;
	}
}
