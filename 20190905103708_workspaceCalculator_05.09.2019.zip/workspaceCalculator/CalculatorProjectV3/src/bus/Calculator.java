package bus;

public class Calculator //class constructor
{
	private int number1;
	private int number2;
	
	//Gets and Sets
	public void setNumber1(int value)
	{
		this.number1 = value;
	}
	public int getNumber1()
	{
		return this.number1;
	}
	
	public void setNumber2(int value)
	{
		this.number2 = value;
	}
	public int getNumber2()
	{
		return this.number2;
	}
	
	//Constructors
	//if you don't add any constructor, the compiler it will add the default constructor
	//if I add a constructor with parameter without the constructor without parameter, the compiler will NOT add a default, however, if I don't have a constructor with parameter and I have with parameter, the compiler will add a default
	public Calculator() 
	{
		this.number1 = 0;
		this.number2 = 0;
	}
	
	public Calculator(int value1, int value2) 
	{
		this.number1 = value1;
		this.number2 = value2;
	}
	
	//Operations
	public int add(int value1, int value2)
	{
		return value1 + value2;
	}
	public int sub(int value1, int value2)
	{
		return value1 - value2;
	}
	public int mult(int value1, int value2)
	{
		return value1 * value2;
	}
	public int div(int value1, int value2)
	{
		if(value2 != 0)
		{ 
			return value1 / value2;
		} 
		return 0;
	}
	public int mod(int value1, int value2)
	{
		return value1 % value2;
	}
	
	//toString //so I have a return that is not the address of the object
	public String toString()
	{
		return "number1 = " + this.number1 + "\nnumber2 = " + number2;
		
	}

}
