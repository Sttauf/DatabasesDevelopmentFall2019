package client;
import bus.Calculator;

//Version 2 - Date: 05.09.2019
public class CalculatorTester3 {
		public static void main(String[] args) 
		{
			Calculator c1 = new Calculator();
			
			//System.out.println(c1); //if i print it it will show the address of calculator, to change it i have to do the ToString, so I will show the statement, which means the value of the c1
			//System.out.println(c1.ToString()); //worked, however I want to call it automatically, so I changed to toString, because in Java has to be lower cause
			
			c1.setNumber1(12);
			c1.setNumber2(2);
			System.out.println(c1);
			System.out.println("\n sum = " + c1.add(c1.getNumber1(), c1.getNumber2()));
			System.out.println("\n sub = " + c1.sub(c1.getNumber1(), c1.getNumber2()));
			System.out.println("\n mult = " + c1.mult(c1.getNumber1(), c1.getNumber2()));
			System.out.println("\n div = " + c1.div(c1.getNumber1(), c1.getNumber2()));
			System.out.println("\n mod = " + c1.mod(c1.getNumber1(), c1.getNumber2()));
			
		}
}
