package client;
import java.util.Scanner;

//Version 1.1 - Date: 03.09.2019
public class CalculatorTester1 
{
	public static void main(String[] args) 
	{
		double n1, n2, result;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("\n\n\t\t Hi... we are building a simple calculator \n");
		System.out.print(" number1 ? : ");
		n1 = scan.nextDouble();
		System.out.print(" number2 ? : ");
		n2 = scan.nextDouble();
		
		result = n1 + n2;
		System.out.println(n1+ " + " + n2 + " = " + result);
		result = n1 - n2;
		System.out.println(n1+ " - " + n2 + " = " + result);
		result = n1 * n2;
		System.out.println(n1+ " * " + n2 + " = " + result);
		if(n2 != 0){
		result = n1 / n2;
		System.out.println(n1+ " / " + n2 + " = " + result);
		}
		scan.close();
	}
}
