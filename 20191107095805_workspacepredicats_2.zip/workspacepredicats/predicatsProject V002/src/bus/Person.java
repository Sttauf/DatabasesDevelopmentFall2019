package bus;
import java.io.Serializable;

public class Person implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private long id;
	private String name;

	public void setID(long id) {
	this.id = id;
}
public long getID() {
	return this.id;
}
		public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public Person(){
		this.id = 0;
		this.name = "";
	}
	public Person(int id, String name){
		this.id = id;
		this.name = name;
	}
	
	public String toString(){
		return "ID:" + this.id + "\n Name:" + this.name;
	}
	
}

