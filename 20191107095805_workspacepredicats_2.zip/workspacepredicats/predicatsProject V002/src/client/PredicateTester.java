package client;
import bus.*;
//import java.io.*;
//INPUT:
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
//OUTPUT:
import java.io.FileInputStream;
import java.io.ObjectInputStream;

import java.io.IOException;
import java.util.ArrayList;


//SERIALIZE EXERCICE 
public class PredicateTester {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		ArrayList<Person> listFromConsole = new ArrayList<Person>();
		ArrayList<Person> listFromFile = new ArrayList<Person>();
		
		listFromConsole.add(new Person(1000, "Sylia Houmel"));
		listFromConsole.add(new Person(1001, "Laura Delinelle"));
		
		//Write into serialized file personal.net
		FileOutputStream fos = new FileOutputStream("personal.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(listFromConsole);
		oos.close();
		
		//Read from serialized file (personal.set) 
		FileInputStream fis = new FileInputStream("personal.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		for(Person record : listFromFile )
		{
			System.out.println(record);
		}
		
		ois.close();
		
	}

}
