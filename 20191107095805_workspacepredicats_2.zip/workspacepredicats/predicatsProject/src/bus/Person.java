package bus;

public class Person {
	private int id;
	private String fn;
	private String ln;
	
	public void setID(int id)
	{
		this.id = id;
	}
	public int getID()
	{
		return this.id;
	}
	public void setFN(String fn)
	{
		this.fn = fn;
	}
	public String getFN()
	{
		return this.fn;
	}
	public void setLN(String ln)
	{
		this.ln = ln;
	}
	public String getLN()
	{
		return this.ln;
	}
	
	public Person(){
		this.id = 0;
		this.fn = "";
		this.ln = "";
	}
	public Person(int id, String fn, String ln){
		this.id = id;
		this.fn = fn;
		this.ln = ln;
	}
	
	public String toString(){
		return "ID:" + this.id + "\n First Name:" + this.fn + "\n Last Name:" + this.ln;
	}
	public String getFullName()
	{
		return this.fn + " " + this.ln;
	}
	
}