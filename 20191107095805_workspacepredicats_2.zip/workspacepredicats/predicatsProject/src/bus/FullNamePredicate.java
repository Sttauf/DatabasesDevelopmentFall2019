package bus;
import java.util.Comparator;
public class FullNamePredicate implements Comparator<Person> {
	public int compare(Person o1, Person o2)
	{
		if(o1.getFullName().compareTo(o2.getFullName()) > 0)
		{
			return +1;
		} else if(o1.getFullName().compareTo(o2.getFullName()) < 0)
		{
			return -1;
		} else {
			return 0;
		}
	}
}
