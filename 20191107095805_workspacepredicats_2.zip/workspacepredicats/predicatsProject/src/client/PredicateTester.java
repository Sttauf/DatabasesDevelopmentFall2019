package client;
import bus.*;
import java.util.ArrayList;
import java.util.Collections;

public class PredicateTester {

	public static void main(String[] args) {
		ArrayList<Person> list1 = new ArrayList<Person>();
		
		list1.add(new Person(7, "aline", "Al"));
		list1.add(new Person(2, "zack", "zack"));
		list1.add(new Person(5, "sami", "sam"));
		
		System.out.println("\n\n List of persons BEFORE sorting: ");
		for(Person element : list1){
			System.out.println(element);
		}

		FullNamePredicate fnPredicat = new FullNamePredicate();
		Collections.sort(list1, fnPredicat);
		
		System.out.println("\n\n List of persons AFTER sortingby NAME: ");
		for(Person element : list1){
			System.out.println(element);
		}
		
		IdPredicate idPredicat = new IdPredicate();
		Collections.sort(list1, idPredicat);
		
		System.out.println("\n\n List of persons AFTER sorting by ID: ");
		for(Person element : list1){
			System.out.println(element);
		}
		

		
	}

}
