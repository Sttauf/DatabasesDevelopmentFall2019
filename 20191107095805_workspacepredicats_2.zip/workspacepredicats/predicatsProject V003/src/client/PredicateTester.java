package client;
import bus.*;
import java.util.Scanner;


public class PredicateTester {
	
	public static void main(String[] args) {		
		Scanner scan = new Scanner(System.in);
		Person p1 = new Person();
		while(true)
		{
			try 
			{
				System.out.print("\n Name: ");
				p1.setName(scan.nextLine());
				break;
			}
			catch(Exception ex) 
			{
				System.out.println("\t\t" + ex.getMessage());
			}
		}	
		scan.nextLine();
		while(true)
		{
			try 
			{
				System.out.print("\n fn: ");
				p1.setName(scan.nextLine());
				break;
			}
			catch(Exception ex) 
			{
				System.out.println("\t\t" + ex.getMessage());
			}
		}	
		System.out.println("\t\t + Tested");
	}

}
