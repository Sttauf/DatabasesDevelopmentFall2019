package bus;

public class Person {
	
	private long id;
	private String name;
	
	public void setID(long id) throws Exception {
	if(!String.valueOf(id).matches("^\\d{8}$"))
	{
		throw new Exception("Must be 8");
	}
		this.id = id;
	}
	public long getID()
	{
		return this.id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) throws Exception {
		if(!name.matches("^[A-Z]{1}[a-z]{2,15}$")){
		throw new Exception("Must be Uppercase in the first ");
	}
		this.name = name;
	}
	public Person(){
		this.id = 0;
		this.name = "";
	}
	public Person(int id, String name){
		this.id = id;
		this.name = name;
	}
	
	public String toString(){
		return "ID:" + this.id + "\n Name:" + this.name;
	}
	
}

