package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDB {
	public static Connection getConnection() throws SQLException{
		Connection myConnectionDB = null;
		String username = "system";
		String password = "123";
		String service = "localhost";
		String url = "jdbc:oracle:thin:";
		myConnectionDB = DriverManager.getConnection(url + username + "/" + password + "@" + service);
		return myConnectionDB;
	}
}
