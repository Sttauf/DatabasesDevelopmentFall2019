package data;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

import java.io.IOException;
import java.util.ArrayList;

import bus.Vehicle;

public class FileHandler {
	ArrayList<Vehicle> listConsole = new ArrayList<Vehicle>();
	ArrayList<Vehicle> listFile = new ArrayList<Vehicle>();

	@SuppressWarnings("unchecked")
	public void saveFile(Vehicle vehicleInput) throws IOException, ClassNotFoundException{
		listConsole.add(vehicleInput);
		
		FileOutputStream fos = new FileOutputStream("vehicle.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(listConsole);
		oos.close();
		
		FileInputStream fis = new FileInputStream("vehicle.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		listFile = (ArrayList<Vehicle>)ois.readObject();
		
		for(Vehicle record : listFile){
			System.out.println(record);
		}
		ois.close();	
	}
	
}
