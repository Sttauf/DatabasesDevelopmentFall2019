package data;
import java.util.ArrayList;

import bus.Vehicle;

public class VehiclesFleet {
	//List with the vehicles:
	private static ArrayList<Vehicle> vehiclelist;
	public VehiclesFleet(){
		setVehiclelist(new ArrayList<Vehicle>());	
	}
	public void setVehiclelist(ArrayList<Vehicle> vehiclelist) {
		VehiclesFleet.vehiclelist = vehiclelist;
	}
	public ArrayList<Vehicle> getVehiclelist() {
		return vehiclelist;
	}
	
	//Static Methods
	public static void add(Vehicle vel){vehiclelist.add(vel);}
	public static void remove(Vehicle vel){vehiclelist.remove(vel);}
	public static void search(int index){vehiclelist.get(index);}
	public static void getSize(){vehiclelist.size();}
}
