package data;
import bus.Vehicle;
public interface IClonableVehicle {
	abstract public Vehicle clone();
}
