package data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import bus.*;

public class BusDB {
	static ArrayList<Vehicle> vehicleList = new ArrayList<Vehicle>();
	static ArrayList<Bus> busList = new ArrayList<Bus>();
	static FileHandler save = new FileHandler();
	
	//INSERT
	public static void add(Bus currentBus, ConnectionDB cb){
		busList.add(currentBus);
		vehicleList.add(currentBus);
		save(currentBus, cb);
	}
	
	//UPDATE
	public static void update(int index, Bus currentBus, ConnectionDB cb) throws ClassNotFoundException{
		busList.set(index, currentBus);
		vehicleList.set(index, currentBus);
		save(currentBus, cb);
	}
	
	//DELETE
	public static void remove(Bus currentBus, ConnectionDB cb){
		busList.remove(currentBus);
		vehicleList.remove(currentBus);
		save(currentBus,cb);
	}
	public static void remove(long serialNumber, ConnectionDB cb){
		busList.remove(serialNumber);
		vehicleList.remove(serialNumber);
	}
	//SELECT
	public static Bus search(int serialNumber){
		int number;
		for(Bus element : busList){
			number = element.getNumber();
			if(number == serialNumber){
				return element;
			}
		}
		return null;	 
	}
	
	//DISPLAY
	public static HashMap<Long,Bus> getList(){
		for(Bus element:busList){
			System.out.print(element);
		}
		return null;
	}
	
	@SuppressWarnings("unused")
	public static void save(Bus b, ConnectionDB cb){
		for(Bus element : busList){
			try{save.saveFile(b);}
			catch(IOException e){e.printStackTrace();}
			catch (ClassNotFoundException e){e.printStackTrace();}			
		}
	}
}
