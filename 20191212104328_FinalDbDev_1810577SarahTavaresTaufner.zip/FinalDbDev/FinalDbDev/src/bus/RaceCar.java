
package bus;

public class RaceCar extends SportCar{
	private double powerCons;
	
	public void setPowerCons(double powerCons) {
		this.powerCons = powerCons;
	}
	public double getPowerCons() {
		return powerCons;
	}

	public RaceCar(Car car)
	{
		super(car);
		this.setPowerCons(0.0);
	}
	public RaceCar(int number, String made, String model, int year, double price, int numOfDoors, double gasCons, double powerCons)
	{
		super(number, made, model, year, price, numOfDoors, gasCons);
		this.setPowerCons(0.0);
	}
	public RaceCar clone(){
		return new RaceCar(this);
	}

}
