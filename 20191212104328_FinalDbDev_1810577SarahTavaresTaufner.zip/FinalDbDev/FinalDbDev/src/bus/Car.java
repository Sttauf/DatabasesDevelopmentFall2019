package bus;

public class Car extends Vehicle{
	private int numOfDoors;
	
	public void setNumOfDoors(int numOfDoors) {
		this.numOfDoors = numOfDoors;
	}
	public int getNumOfDoors() {
		return numOfDoors;
	}

	public Car(Car car)
	{
		super();
		this.setNumOfDoors(0);
	}
	public Car(int number, String made, String model, int year, double price, int numOfDoors)
	{
		super(number, made, model, year, price);
		this.setNumOfDoors(0);
	}

	public Car clone(){
		return new Car(this);
	}

}
