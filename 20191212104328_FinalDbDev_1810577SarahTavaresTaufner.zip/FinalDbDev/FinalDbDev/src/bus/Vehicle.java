package bus;
import data.*;

public abstract class Vehicle implements IClonableVehicle{
	private int number;
	private String made; //brand
	private String model;
	private int year;
	private double price;
	
	public abstract Vehicle clone();
	
	public void setNumber(int number) {
		this.number = number;
	}
	public int getNumber() {
		return number;
	}
	public void setMade(String made) {
		this.made = made;
	}
	public String getMade() {
		return made;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getModel() {
		return model;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getYear() {
		return year;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getPrice() {
		return price;
	}
	public Vehicle(){
		this.number = 0;
		this.made = "undefined";
		this.model = "undefined";
		this.year = 0000;
		this.price = 0.0;
	}
	public Vehicle(int number2, String made2, String model2, int year2, double price2) {
		this.number = number2;
		this.made = made2;
		this.model = model2;
		this.year = year2;
		this.price = price2;
	}
}
