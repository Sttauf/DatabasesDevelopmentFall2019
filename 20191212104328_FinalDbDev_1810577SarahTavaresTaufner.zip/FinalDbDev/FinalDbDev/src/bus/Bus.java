package bus;
import java.util.HashMap;

import data.*;

public class Bus extends Vehicle {
	private int capPassengers;

	public void setCapPassengers(int capPassengers) {
		this.capPassengers = capPassengers;
	}

	public int getCapPassengers() {
		return capPassengers;
	}
	public Bus(Bus bus)
	{
		super();
		this.capPassengers = 0;
	}
	public Bus(int number, String made, String model, int year, double price, int capPessenger)
	{
		super(number, made, model, year, price);
		this.capPassengers = 0;
	}
	
	public Bus clone(){
		return new Bus(this);
	}
	public static void add(Bus b, ConnectionDB cb){
		BusDB.add(b, cb);
	}
	public static void remove(Bus b, ConnectionDB cb){
		BusDB.remove(b, cb);
	}
	public static void remove(long sn, ConnectionDB cb){
		BusDB.remove(sn, cb);
	}
	public static Bus search(int serialNumber){
		return BusDB.search(serialNumber);
	}
	public static HashMap<Long, Bus> getList(){
		return BusDB.getList();
	}
}
