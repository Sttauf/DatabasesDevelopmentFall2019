package bus;

public class SportCar extends Car {
	private double gasCons;
	
	public void setGasCons(double gasCons) {
		this.gasCons = gasCons;
	}
	public double getGasCons() {
		return gasCons;
	}

	public SportCar(Car car)
	{
		super(car);
		this.setGasCons(0.0);
	}
	public SportCar(int number, String made, String model, int year, double price, int numOfDoors, double gasCons)
	{
		super(number, made, model, year, price, numOfDoors);
		this.setGasCons(0.0);
	}
	
	public SportCar clone(){
		return new SportCar(this);
	}

}
