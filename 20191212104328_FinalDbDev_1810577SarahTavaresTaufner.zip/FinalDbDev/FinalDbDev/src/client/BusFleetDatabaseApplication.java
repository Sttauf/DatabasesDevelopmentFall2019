package client;
import bus.*;
import data.*;
import java.util.Scanner;

public class BusFleetDatabaseApplication {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Bus b = new Bus(123, "Brand", "67s7" , 1, 2.2, 4);
		ConnectionDB cb = new ConnectionDB(); 
		
		System.out.print("\n Menu? \n 1)Add bus \n 2)Remove bus by name \n 3) Remove bus by serial number \n 4)Search bus by serial number \n 5) Display buses");
		switch(scan.nextInt()){
		//add
		case 1: Bus.add(b, cb);break;
		//remove by name
		case 2: Bus.remove(b, cb); break;
		//remove by serial number
		case 3: Bus.remove(b.getNumber(), cb); break;
		//search
		case 4: Bus.search(b.getNumber()); break;
		//display
		case 5: Bus.getList(); break;
		default: break;
		}
		
	}

}
