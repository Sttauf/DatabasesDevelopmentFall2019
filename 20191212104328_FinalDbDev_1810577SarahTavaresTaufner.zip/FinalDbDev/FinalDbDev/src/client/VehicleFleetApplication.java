package client;
import bus.*;
import data.*;
public class VehicleFleetApplication {
	@SuppressWarnings("null")
	public static void main(String[] args) {
		Vehicle vel = null;
		vel.setNumber(12);
		vel.setMade("Brand");
		vel.setModel("G6");
		vel.setPrice(23.333);
		vel.setYear(2019);
		
		VehiclesFleet.add(vel);
		VehiclesFleet.search(12);
		VehiclesFleet.getSize();
	
	}

}
