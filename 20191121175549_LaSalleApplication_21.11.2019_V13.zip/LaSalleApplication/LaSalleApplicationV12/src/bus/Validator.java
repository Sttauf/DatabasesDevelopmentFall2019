package bus;

public class Validator {
	private static long id;	
	private static String fn;
	private static String ln;
	public static void setId(long val) throws Exception{
		if(!String.valueOf(id).matches("^\\d{8}$"))
		{
			throw new Exception("Must be 8 digits");
		}
			id = val;
		}
	public static void setFN(String name)throws Exception{
		if(!name.matches("^[A-Z]{1}[a-z]{2,15}$")){
			throw new Exception("Must be Uppercase in the first ");
		}
			fn = name;
	}
	public static void setLN(String name)throws Exception{
		if(!name.matches("^[A-Z]{1}[a-z]{2,15}$")){
			throw new Exception("Must be Uppercase in the first ");
		}
			ln = name;
	}

}
