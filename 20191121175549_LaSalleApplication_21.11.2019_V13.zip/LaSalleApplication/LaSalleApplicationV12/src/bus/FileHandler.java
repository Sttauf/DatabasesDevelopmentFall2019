package bus;

import java.io.FileOutputStream; 
import java.io.ObjectOutputStream;

import java.io.FileInputStream; 
import java.io.ObjectInputStream;

import java.io.IOException;
import java.util.ArrayList;

public class FileHandler  {
	
		ArrayList<Member> listFromConsole = new ArrayList<Member> ();
		ArrayList<Member> listFromFile = new ArrayList<Member> ();
		
		@SuppressWarnings("unchecked")
		public void saveFile(Member input) throws IOException, ClassNotFoundException		
		{
			listFromConsole.add(input);
			listFromConsole.add(input);
			
		FileOutputStream fos = new FileOutputStream("serialize.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(listFromConsole);
		oos.close();

		FileInputStream fis = new FileInputStream("personal.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		listFromFile = (ArrayList<Member>) ois.readObject();
		
		for(Member record : listFromFile )
		{
			System.out.println(record);
		}
		
		ois.close();
		}
}
