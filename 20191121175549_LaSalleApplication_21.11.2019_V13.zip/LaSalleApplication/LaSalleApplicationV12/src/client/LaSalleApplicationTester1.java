package client;

import java.io.IOException;
import java.util.ArrayList;

import bus.*;



public class LaSalleApplicationTester1 {

public static void main(String[] args){
		
		ArrayList<Member> memberList = new ArrayList<Member>();
		ArrayList<Student> studentList = new ArrayList<Student>();
		ArrayList<Employee> employeeList = new ArrayList<Employee>();
		FileHandler save = new FileHandler();
		
		memberList.add(new Student(4,"Sarah", "Taufner", 3.3));
		memberList.add(new Student(2,"Komal","KOmal",2.2));
		memberList.add(new Student(3,"Hayehdeh", "Ljdhsk", 5.3));	
		memberList.add(new Student(1,"Ali","Hage",2.2));
		
		for(Member element : memberList)
		{
			if(element instanceof Student)//Downcasting
			{
				studentList.add((Student)element);
			}else if(element instanceof Employee)
			{
				employeeList.add((Employee)element);
			}
		}
		for(Member element : memberList)
		{
			try {
				save.saveFile(element);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}

		System.out.println();
		
}}