package client;
import java.io.IOException;
import java.util.ArrayList;
import java.io.FileOutputStream; import java.io.ObjectOutputStream;
import java.io.FileInputStream; import java.io.ObjectInputStream;
import bus.*;



public class LaSalleApplicationTester1 {

@SuppressWarnings("unchecked")
public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		ArrayList<Member> memberList = new ArrayList<Member>();
		
		memberList.add(new Student(4,"Sarah", "Taufner", 3.3));
		memberList.add(new Student(2,"Komal","KOmal",2.2));
		memberList.add(new Student(3,"Hayehdeh", "Ljdhsk", 5.3));	
		memberList.add(new Student(1,"Ali","Hage",2.2));

		System.out.println();
		FileOutputStream fos = new FileOutputStream("personal.ser");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(memberList);
		oos.close();
		FileInputStream fis = new FileInputStream("personal.ser");
		ObjectInputStream ois = new ObjectInputStream(fis);
		memberList =   (ArrayList<Member>) ois.readObject();

		for(Member record : memberList )
		{
			System.out.println(record);
		}
		
		ois.close();
}}