package bus;

public class Date {
	private int month;
	private int day;
	private int year;
	
	public void setDay(int d)
	{
		this.day = d;
	}
	public int getDay()
	{
		return this.day;
	}
	
	public void setMonth(int m)
	{
		this.month = m;
	}
	public int getMonth()
	{
		return this.month;
	}
	
	public void setYear(int y)
	{
		this.year = y;
	}
	public int getYear(int y)
	{
		return this.year;
	}
	
	public Date()
	{
		this.day = 00;
		this.month = 00;
		this.year = 0000;
	} 
	public Date(int d, int m, int y)
	{
		this.day = d;
		this.month = m;
		this.year = y;
	}
	public String toString()
	{
		return this.day + "." + this.month + "." + this.year;
	}	
}
