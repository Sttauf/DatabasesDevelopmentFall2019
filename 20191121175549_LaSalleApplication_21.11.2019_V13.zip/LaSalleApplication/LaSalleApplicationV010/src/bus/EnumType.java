package bus;

public enum EnumType {
	Undefined, Student, Employee, Customer;
}
