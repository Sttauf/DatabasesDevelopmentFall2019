package bus;

public class Course {
	Teacher teacher;
	Student student;
}
