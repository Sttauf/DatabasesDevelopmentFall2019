package bus;

public class Teacher extends Employee {

}
