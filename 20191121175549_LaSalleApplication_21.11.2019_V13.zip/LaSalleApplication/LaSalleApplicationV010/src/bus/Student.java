package bus;
public class Student extends Member{
	private double feesPerSession;
	
	public void setFeesPerSession(double feesPerSession) {
		this.feesPerSession = feesPerSession;
	}
	public double getFeesPerSession() {
		return feesPerSession;
	}
	public Student()
	{
		super();
		this.feesPerSession = 0.0;
	} 
	public Student(int id, String fname, String lname, double fees)
	{
		super(id, fname, lname);
		this.feesPerSession = fees;
	}
	public String toString()
	{
		return super.toString() + "\nFees per session: " + this.feesPerSession;
	}
	@Override
	public double calculPayment() {
		return this.feesPerSession;
	}
}
