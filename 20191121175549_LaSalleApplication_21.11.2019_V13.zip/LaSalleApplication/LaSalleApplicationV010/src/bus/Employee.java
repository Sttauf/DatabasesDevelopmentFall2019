package bus;

public class Employee extends Member{
	private double annualSalary;
	private double hoursPerWeek;
	private double hourlyRate;
	public void setHoursPW(double hourPW)
	{
		this.hoursPerWeek = hourPW;
	}
	public double getHourPW()
	{
		return this.hoursPerWeek;
	}
	public void setHourR(double hourR)
	{
		this.hourlyRate = hourR;
	}
	public double getHourR()
	{
		return this.hourlyRate;
	}
	public void setAnnualSalary(double annualSalary) {
		this.annualSalary = annualSalary;
	}
	public double getAnnualSalary() {
		return annualSalary;
	}	
	public Employee()
	{
		super();
		this.annualSalary = 0.0;
		this.hoursPerWeek = 0.0;
		this.hourlyRate = 0.0;
	} 
	public Employee(int id, String fname, String lname, double salary, double hourPW, double hourR)
	{
		super(id,fname,lname);
		this.annualSalary = salary;
		this.hoursPerWeek = hourPW;
		this.hourlyRate = hourR;
	}
	public String toString()
	{
		return super.toString() + "\nAnnual Salary: " + this.annualSalary + "\nHours per week: " + this.hoursPerWeek + "\nHourly Rate: " + this.hourlyRate;
	}
	@Override
	public double calculPayment() {
		return this.hourlyRate * this.hoursPerWeek;
	}
}
