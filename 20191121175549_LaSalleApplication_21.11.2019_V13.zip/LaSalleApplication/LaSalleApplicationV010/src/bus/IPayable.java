package bus;

public interface IPayable {
 public abstract double calculPayment();
}
