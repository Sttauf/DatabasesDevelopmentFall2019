package bus;

public abstract class Member implements IPayable{
private int id;
private String fn;
private String ln;
public Date date;
public EnumType enumt;


public void setId(int val){this.id = val;}
public int getId(){return this.id;}

public void setFN(String name){this.fn = name;}
public String getFN(){return this.fn;}

public void setLN(String name){this.ln = name;}
public String getLN(){return this.ln;}

public Member()
{
	this.id = 0;
	this.fn = "undefined";
	this.ln = "undefined";
}
public Member(int val, String nameF, String nameL){
	this.id = val;
	this.fn = nameF;
	this.ln = nameL;
}
public abstract double calculPayment();
public String toString()
{
	return "id: " + this.id + "\nFirst Name: " + this.fn + "\nLast Name: " + this.ln;	
}
}