package data;
import java.io.IOException;
import java.util.ArrayList;
import bus.*;
public class StudentDb {
	static ArrayList<Member> memberList = new ArrayList<Member>();
	static ArrayList<Student> studentList = new ArrayList<Student>();
	static ArrayList<Employee> employeeList = new ArrayList<Employee>();
	static FileHandler save = new FileHandler();
	
	public static void insert(Student s, SingletonConnection c){
		memberList.add(s);
		StudentDb.defineList(s, c);		
	}
	public static void delete(Student s, SingletonConnection c){
		memberList.remove(s);
	}
	public static void delete(long key, SingletonConnection c){
		memberList.remove(key);
	}
	
	public static void defineList(Student s, SingletonConnection c){
		for(Member element : memberList)
		{
			if(element instanceof Student)
			{
				studentList.add((Student)element);
			}else if(element instanceof Employee)
			{
				employeeList.add((Employee)element);
			}
		}
	}
	public static void save(Student s, SingletonConnection c){
		for(Member element : memberList)
		{
			try {
				save.saveFile(element);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
	}
}
