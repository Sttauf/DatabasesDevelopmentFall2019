package client;
import bus.*;
import data.*;
import java.util.Scanner;
public class LaSalleApplicationTester1 {

public static void main(String[] args){
		Student s = new Student();
		SingletonConnection c = new SingletonConnection();
		Scanner scan = new Scanner(System.in);
		int op=1;
			
		System.out.print("\n Menu: \n 1) add student \n 2) remove student \n\n");
		scan.nextInt(op);
		switch(op){
		case 1: Student.add(s, c);
		case 2: Student.remove(s, c);
		}
		
		System.out.println();
		
}}