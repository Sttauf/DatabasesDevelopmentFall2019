package client;
import java.util.ArrayList;
import bus.*;

//CREATE FUNCTIONS!!!

public class LaSalleApplicationTester1 {

public static void main(String[] args) {
		
		ArrayList<Member> memberList = new ArrayList<Member>();
		ArrayList<Student> studentList = new ArrayList<Student>();
		ArrayList<Employee> employeeList = new ArrayList<Employee>();
		
		//Member s1 = new Student(1,"a","b",2.2);
		//Member e1 = new Employee(3,"e","f",3.3);		
		//memberList.add(s1);
		//memberList.add(e1);
		
		memberList.add(new Student(1,"a","b",2.2));
		memberList.add(new Employee(3,"e", "f", 3.3));
		
		System.out.println();
		for(Member element : memberList)
		{
			if(element instanceof Student)//Downcasting
			{
				studentList.add((Student)element);
			}else if(element instanceof Employee)
			{
				employeeList.add((Employee)element);
			}
		}
		System.out.println("\nList of Members: ");
		for(Member aMember : memberList)
		{
			System.out.println(aMember);
		}
		System.out.println("\nList of Students: ");
		for(Student aStudent : studentList)
		{
			System.out.println(aStudent);
		}
		System.out.println("\nList of Employees: ");
		for(Employee aEmployee : employeeList)
		{
			System.out.println(aEmployee);
		}

		//for(Member aMember : memberList)
		//{
		//	System.out.println(aMember);
		//}
		//System.exit(0);
	}


}
