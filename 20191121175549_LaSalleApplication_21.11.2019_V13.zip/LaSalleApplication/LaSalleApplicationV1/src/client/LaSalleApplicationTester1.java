package client;
import bus.Member;
import bus.Student;
import bus.Employee;

public class LaSalleApplicationTester1 {

	public static void main(String[] args) {
		Member m1 = new Member(2, "c","d");
		Student s1 = new Student(1,"a","b",2.2);
		Employee e1 = new Employee(3,"e","f",3.3);
		System.out.println(s1);
		System.out.println(m1);
		System.out.println(e1);
	}
	
}
