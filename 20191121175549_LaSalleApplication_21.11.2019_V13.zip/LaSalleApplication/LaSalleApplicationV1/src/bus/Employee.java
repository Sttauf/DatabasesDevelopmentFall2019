package bus;

public class Employee extends Member{
	private double annualSalary;
	public void setAnnualSalary(double annualSalary) {
		this.annualSalary = annualSalary;
	}
	public double getAnnualSalary() {
		return annualSalary;
	}	
	public Employee()
	{
		super();
		this.annualSalary = 0.0;
	} 
	public Employee(int id, String fname, String lname, double salary)
	{
		super(id,fname,lname);
		this.annualSalary = salary;
	}
	public String toString()
	{
		return super.toString() + "\nAnnual Salary: " + this.annualSalary;
	}

}
