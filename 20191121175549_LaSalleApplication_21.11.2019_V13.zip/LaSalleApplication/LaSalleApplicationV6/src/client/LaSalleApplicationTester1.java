package client;
import java.util.Scanner;
import bus.*;


public class LaSalleApplicationTester1 {

public static void main(String[] args) {		
		Scanner scan = new Scanner(System.in);
		Company laSalle = new Company();
		Student s1 = new Student();
		Employee e1 = new Employee();
		//Member m1 = new Member();
		int option = 2;
		System.out.print("Which kind of membr do you wanna add? 1 = Student / 0 = Employee");
		scan.nextInt(option);		
		if(option == 1)
		{
			laSalle.add(s1);
			System.out.print("\n ID: ");
			s1.setId(scan.nextInt());
			System.out.print("\n First Name: ");
			s1.setFN(scan.next());
			System.out.print("\n Last Name: ");
			s1.setLN(scan.next());
			System.out.print("\n Fees per Session: ");
		}
		if(option == 0)
		{
			laSalle.add(e1);
		}
		
		

		
	}
}
/*package client;
//import bus.Calculator;

//Version 2 - Date: 05.09.2019
public class CalculatorTester3 {
		public static void main(String[] args) 
		{
			Calculator c1 = new Calculator();
			
			//System.out.println(c1); //if i print it it will show the address of calculator, to change it i have to do the ToString, so I will show the statement, which means the value of the c1
			//System.out.println(c1.ToString()); //worked, however I want to call it automatically, so I changed to toString, because in Java has to be lower cause
			
			c1.setNumber1(12);
			c1.setNumber2(2);
			System.out.println(c1);
			System.out.println("\n sum = " + c1.add(c1.getNumber1(), c1.getNumber2()));
			System.out.println("\n sub = " + c1.sub(c1.getNumber1(), c1.getNumber2()));
			System.out.println("\n mult = " + c1.mult(c1.getNumber1(), c1.getNumber2()));
			System.out.println("\n div = " + c1.div(c1.getNumber1(), c1.getNumber2()));
			System.out.println("\n mod = " + c1.mod(c1.getNumber1(), c1.getNumber2()));
			
		}
		
	package client;
import java.util.Scanner;

//Version 1.2 - Date: 03.09.2019
public class CalculatorTester2 
{
	public static void main(String[] args) 
	{
		double n1, n2;
		Scanner scan = new Scanner(System.in);
		
		System.out.println("\n\n\t\t Hi... we are building a simple calculator \n");
		System.out.print(" number1 ? : ");
		n1 = scan.nextDouble();
		System.out.print(" number2 ? : ");
		n2 = scan.nextDouble();
		
		System.out.println(n1+ " + " + n2 + " = " + add(n1,n2));
		System.out.println(n1+ " - " + n2 + " = " + sub(n1,n2));
		System.out.println(n1+ " * " + n2 + " = " + mult(n1,n2));
		System.out.println(n1+ " / " + n2 + " = " + div(n1,n2));
		scan.close();
	}
	private static double add(double n1, double n2) 
	{
		return n1 + n2;
	}
	private static double sub(double n1, double n2) 
	{
		return n1 - n2;
	}
	private static double mult(double n1, double n2) 
	{ 
		return n1 * n2; 
	}
	private static double div(double n1, double n2) 
	{
		if(n2 != 0)
		{ 
			return n1 / n2;
		} 
		return 0;
	}
}

		
*/