/*Week 11 - FT 03 - Version 03
                OJDBC Connection- DML statements -Query
TO DO:
in the class tester, create the public static functions to:
1- display students
2- add a new student
3- remove a  student knowing his key
4- to modify the name of a specific student  knowing his key
5- the main function must invoke each previous functions (Add a menu)*/
package prod;

//java.sun.com -- open the java API and the package java.sql

//import java.sql.Collection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.util.Scanner;

import bus.Function;

public class dbTester1
{
	public static void main(String[] args) throws SQLException{
		
	Scanner scan = new Scanner(System.in);
	Connection myConnection = null;
	int op = 1;
	String username = "system";
	String password = "123";
	String service = "localhost";
	String url = "jdbc:oracle:thin:";

	myConnection = DriverManager.getConnection(url + username + "/" + password + "@" + service);
	System.out.println("\n\t Connection established");
	System.out.print("\n\n Menu: \n 1)DISPLAY \n 2)ADD \n 3)REMOVE \n");
	scan.nextInt(op);
	switch(op){
	case 1: Function.displayTable(); break;
	case 2: Function.addTable(); break;
	case 3: Function.removeTable(); break;
	default: break;
	}
	System.out.println("\n EXIT");
	
	System.exit(0);
	}
}