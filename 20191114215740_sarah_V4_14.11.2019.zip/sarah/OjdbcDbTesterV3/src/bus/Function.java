package bus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Function {
	static Scanner scan = new Scanner(System.in);
	static Connection myConnection = null;
	static PreparedStatement myPrepStmt;
	static int stud_id;
	static String stud_name;
	static String sqlStmt;
	public static void displayTable() throws SQLException{
		//2) display data
		System.out.println("\n Student list:");
		
		String sqlQuery = "select * from student";
		
		Statement myStatement = null;
		ResultSet myResulSet = null;
		
		myStatement = myConnection.createStatement();
		myResulSet = myStatement.executeQuery(sqlQuery);
		
		String id,name;
		while(myResulSet.next())
		{
			id = myResulSet.getString(1);
			name = myResulSet.getString(2);
			
			System.out.println(id + " | " + name);
		}
		}
	public static void addTable() throws SQLException{

		//3) add student
		System.out.println("\n Add a new student:");
		
		System.out.println("input id: ");
		
		stud_id = scan.nextInt();
		scan.nextLine();
		
		System.out.println("input name: ");
		
		stud_name = scan.nextLine();
		
		sqlStmt = "insert into student values( ? , ? )";
		
		myPrepStmt = myConnection.prepareStatement(sqlStmt);
		
		myPrepStmt.setInt(1, stud_id);
		myPrepStmt.setString(2, stud_name);
		
		myPrepStmt.executeUpdate();
		myConnection.commit();
		
	}
	public static void removeTable() throws SQLException{
		//4) remove a student
		System.out.println("\n Remove a student (knowning its key)\n");
		
		System.out.println("id: ");
		int key = scan.nextInt();
		sqlStmt = "delete from student where id = " + key;
		myPrepStmt = myConnection.prepareStatement(sqlStmt);
		
		myPrepStmt.executeUpdate();	
		myConnection.commit();
	}	
	}
