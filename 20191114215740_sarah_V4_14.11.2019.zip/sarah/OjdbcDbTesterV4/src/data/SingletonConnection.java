package data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SingletonConnection {

	public static Connection getConnection() throws SQLException {
		Connection myConnection = null;
		String username = "system";
		String password = "123";
		String service = "localhost";
		String url = "jdbc:oracle:thin:";
		myConnection = DriverManager.getConnection(url + username + "/" + password + "@" + service);
		return myConnection;
	}

}
