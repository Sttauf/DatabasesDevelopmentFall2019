
package prod;

//java.sun.com -- open the java API and the package java.sql

import java.sql.SQLException;
import java.sql.Connection;
import java.util.Scanner;
import bus.Function;

public class dbTester1
{
	public static void main(String[] args) throws SQLException{
	Scanner scan = new Scanner(System.in);
	int op = 1;
	
	//1) Connect to database
	Connection currentConnection = data.SingletonConnection.getConnection();
	
	System.out.print("\n\n Menu: \n 1)DISPLAY \n 2)ADD \n 3)REMOVE \n");
	scan.nextInt(op);
	switch(op){
	case 1: Function.displayTable(); break;
	case 2: Function.addTable(); break;
	case 3: Function.removeTable(); break;
	default: break;
	}
	System.out.println("\n EXIT");
	
	System.exit(0);
	}
}