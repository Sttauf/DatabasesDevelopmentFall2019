//Week 11 - FT 01 - OJDBC Connection 
//OJDBC Connection 
//Communication between:
// Java application & RDBMS (Oracle)
package prod;

//java.sun.com -- open the java API and the package java.sql

//import java.sql.Collection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class dbTester1
{
	public static void main(String[] args) throws SQLException{
		
	Scanner scan = new Scanner(System.in);
	Connection myConnection = null;
	String username = "system";
	String password = "123";
	String service = "localhost";
	String url = "jdbc:oracle:thin:";

	myConnection = DriverManager.getConnection(url + username + "/" + password + "@" + service);
	System.out.println("\n\t Connection established");
	
	//2) display data
	System.out.println("\n Student list:");
	
	String sqlQuery = "select * from student";
	
	Statement myStatement = null;
	ResultSet myResulSet = null;
	
	myStatement = myConnection.createStatement();
	myResulSet = myStatement.executeQuery(sqlQuery);
	
	String id,name;
	while(myResulSet.next())
	{
		id = myResulSet.getString(1);
		name = myResulSet.getString(2);
		
		System.out.println(id + " | " + name);
	}
	
	//3) add student
	PreparedStatement myPrepStmt;
	int stud_id;
	String stud_name;
	
	System.out.println("\n Add a new student:");
	
	System.out.println("input id: ");
	
	stud_id = scan.nextInt();
	scan.nextLine();
	
	System.out.println("input name: ");
	
	stud_name = scan.nextLine();
	
	String sqlStmt = "insert into student values( ? , ? )";
	
	myPrepStmt = myConnection.prepareStatement(sqlStmt);
	
	myPrepStmt.setInt(1, stud_id);
	myPrepStmt.setString(2, stud_name);
	
	myPrepStmt.executeUpdate();
	myConnection.commit();
	
	//4) remove a student
	System.out.println("\n Remove a student (knowning its key)\n");
	
	System.out.println("id: ");
	int key = scan.nextInt();
	sqlStmt = "delete from student where id = " + key;
	myPrepStmt = myConnection.prepareStatement(sqlStmt);
	
	myPrepStmt.executeUpdate();	
	myConnection.commit();
	
	System.out.println("\n EXIT");
	
	System.exit(0);
	}
}